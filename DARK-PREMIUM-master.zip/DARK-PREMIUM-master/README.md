# DARK-PREMIUM
gunakan dengan bijak ya
Kesalahan bukan tanggung jawab kami
# INSTALLED
$pkg update upgrade
$pkg install git python python2
$pip2 install requests mechanize
$pkg install ruby && gem install lolcat colorama
$git clone https://github.com/D0PP3L64N63R/DARK-PREMIUM && cd DARK-PREMIUM && python2 DarkPremium.py
# NOTIFIKASI
gunakan akun facebook kamu yang masih aktif 
masukkan email/id/no dan password dengan benar agar tidak terjadi kesalahan saat login ke script ini


# S3M064 B3RM4NF44T
# D0PP3L64N63R CYBER
